$( document ).ready(function() {



    $(document).on('change', '.option-click', function(){
        id = $(this).val();
        
        getOption(id);
    })
    function getOption(id) {
        var option = '';
        $.ajax({
            url :'/manage/option/'+ id,
            success: function(response) {
                if( response.messages == "success") {
                    $.each(response.data, function(key, value) {
                        option += '<div class="form-group col-md-8">' +
                        value.title +
                        '</div>' +
                        '<div class="form-group col-md-2">'+
                            '<a href="/manage/option/delete/'+ value.id +'?option='+ response.position +'">Xoá</a>'+
                        '</div>'+
                        '<div class="form-group col-md-2">'+
                            '<a href="/manage/option/edit/'+ value.id +'?option='+ response.position +'">Sửa</a>'+
                        '</div>';
                    })
                    $('.list-option').html(option);
                }
            }
        })
    }
    if( document.getElementById('parent').checked) {
        
    }
});