<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Ram extends Model
{
    protected $table = 'ram';
}
