<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Pin extends Model
{
    protected $table = 'pin';
}
