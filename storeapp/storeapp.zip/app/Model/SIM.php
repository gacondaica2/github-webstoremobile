<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SIM extends Model
{
    protected $table = 'sim';
}
