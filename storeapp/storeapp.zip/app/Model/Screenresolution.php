<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Screenresolution extends Model
{
    protected $table = 'screenresolution';
}
