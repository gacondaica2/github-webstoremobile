<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class screen extends Model
{
    protected $table = 'screens';
}
