<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Screensize extends Model
{
    protected $table = 'screensize';
}
