<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class province extends Model
{
    protected $table = 'province';
}
