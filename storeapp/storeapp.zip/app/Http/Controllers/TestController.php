<?php

namespace App\Http\Controllers;

use GuzzleHttp\Client;
use Illuminate\Http\Request;

class TestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        try {
            $client = new Client([
                'headers' => ['Content-Type' => 'application/json', 'token' => '637170d5-942b-11ea-9821-0281a26fb5d4']
            ]);
            $response = $client->post('https://dev-online-gateway.ghn.vn/shiip/public-api/v2/shipping-order/create',[
                'body' => json_encode([
                    "payment_type_id"   =>  2,
                    "note"              => "Tintest 123",
                    "required_note"     => "KHONGCHOXEMHANG",
                    "return_phone"      => "0332190458",
                    "return_address"    => "39 NTT",
                    'shop_id'           => 1446,
                    "return_district_id"=> 1452,
                    "return_ward_code"  => "1B1508",
                    "client_order_code" => "",
                    "to_name"           => "TinTest124",
                    "to_phone"          => "0987654321",
                    "to_address"        => "72 Thành Thái, Phường 14, Quận 10, Hồ Chí Minh, Vietnam",
                    "to_ward_code"      => "20107",
                    "to_district_id"    => 1442,
                    "cod_amount"        => 200000,
                    "content"           => "ABCDEF",
                    "weight"            => 200,
                    "length"            => 15,
                    "width"             => 15,
                    "height"            => 15,
                    "pick_station_id"   => 0,
                    "deliver_station_id"=> 0,
                    "insurance_value"   => 2000000,
                    "service_id"        => 1,
                    "service_type_id"   =>2,
                    "items"             => [
                        "name"      => "quần dài",
                        "code"      => "sip123",
                        "quantity"  => 1
                    ]
                ])
            ]);
            $data = json_decode($response->getBody()->getContents());
            dd($data);
        }catch(\Exception $e) {
            dd($e->getMessage());
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
