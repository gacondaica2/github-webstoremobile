@extends('frontend.template')
@section('content')
@endsection