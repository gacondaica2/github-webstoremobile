@extends('backend.template')
@section('content')
<div class="main-content">
    <div class="page-header">
        <h2 class="header-title">Danh sach sản phẩm</h2>
        <div class="header-sub-title">
            <nav class="breadcrumb breadcrumb-dash">
                <a href="#" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>
            </nav>
        </div>
    </div>
    @include('backend.messages.messages')
    <div class="card">
        <div class="card-body">
            <h4>Tất cả sản phẩm</h4>
            <p>mô tả danh mục sản phẩm(description)</p>
            <div class="m-t-25">
                <table id="data-table" class="table">
                    <thead>
                        <tr>
                            <th>Tên</th>
                            <th>Trạng thái</th>
                            <th>Quan hệ</th>
                            <th>Chỉnh sửa</th>
                            <th>Xoá</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if( count($category) > 0)
                            @foreach( $category as $item)
                            <tr>
                                <td>{{ $item->title }}</td>
                                <td>{{ $item->status }}</td>
                                <td>{{ $item->parent_id }}</td>
                                <td><a class="btn btn-outline-primary" href="{{ route('edit_category', $item->id) }}">edit</a></td>
                                <td><a class="btn btn-outline-primary" href="{{ route('delete_category', $item->id) }}" >delete</a></td>
                            </tr>
                            @endforeach
                        @endif
                    </tbody>
                </table>
                {{ $category->links() }}
            </div>
        </div>
    </div>
</div>
@endsection