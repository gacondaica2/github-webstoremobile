
<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="page-header">
        <h2 class="header-title">Danh sach đơn hàng</h2>
        <div class="header-sub-title">
            <nav class="breadcrumb breadcrumb-dash">
                <a href="<?php echo e(route('home')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>
            </nav>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <h4>Tất cả đơn hàng</h4>
            <div class="m-t-25">
                <table id="data-table" class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tên người mua</th>
                            <th>Tổng tiền</th>
                            <th>HÌnh thức thanh toán </th>
                            <th>Tình trạng</th>
                            <th>Xem</th>
                            <th>Xoá đơn hàng</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if( count($records) > 0): ?>
                            <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->Order_delivery->name); ?></td>
                                <td><?php echo e(number_format($item->total)); ?></td>
                                <td><?php echo e(($item->paymod == 0) ?'Tại cửa hàng':'GHN'); ?></td>
                                <td><?php echo e(($item->status == 0) ? "Chưa xác nhận" : "Đã xác nhận"); ?></td>
                                <td><a href="<?php echo e(route('order_detail_view', $item->id)); ?>">Chi tiết</a></td>
                                <td><a href="<?php echo e(route('delete_order', $item->id)); ?>">Xoá</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php echo e($records->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DoAnChuyenNganh\project\storeapp\resources\views/backend/order/index.blade.php ENDPATH**/ ?>