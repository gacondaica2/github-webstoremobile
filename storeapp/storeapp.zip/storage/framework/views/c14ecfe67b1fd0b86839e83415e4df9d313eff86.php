
<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="page-header">
        <h2 class="header-title">Danh sach sản phẩm</h2>
        <div class="header-sub-title col-md6">
            <nav class="breadcrumb breadcrumb-dash">
                <a href="#" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>
            <nav>
        </div>
    </div>
    <?php echo $__env->make('backend.messages.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <h4>Tất cả sản phẩm</h4>
                <p>mô tả danh mục sản phẩm(description)</p>
            </div>
            <div class="col-md-6">
                <nav class="navbar navbar-light">
                    <form action="<?php echo e(route('search_product')); ?>" method="POST" class="form-inline">
                        <?php echo csrf_field(); ?>
                        <input class="form-control mr-sm-2" name="name" type="search" placeholder="Tìm kiếm" aria-label="Search">
                        <button class="btn my-2 my-sm-0" type="submit">Tìm</button>
                    </form>
                </nav>
            </div>
        </div>
            <div class="m-t-25">
                <table id="data-table" class="table">
                    <thead>
                        <tr>
                            <th>Tên</th>
                            <th>Mã sản phẩm</th>
                            <th>Số lượng</th>
                            <th>Giá </th>
                            <th>Giá khuyễn mãi</th>
                            <th>Chỉnh sửa</th>
                            <th>Xoá</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if( count($records) > 0): ?>
                            <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->sku); ?></td>
                                <td><?php echo e($item->qty); ?></td>
                                <td><?php echo e($item->price); ?></td>
                                <td><?php echo e($item->price_sale); ?></td>
                                <td><a href="<?php echo e(route('edit_product', $item->id)); ?>">edit</a></td>
                                <td><a href="<?php echo e(route('delete_product', $item->id)); ?>">Delete</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php echo e($records->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DoAnChuyenNganh\project\storeapp\resources\views/backend/product/product.blade.php ENDPATH**/ ?>