
<?php $__env->startSection('content'); ?>
<div class="kenne-cart-area">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('frontend.messages.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if( count( Cart::getContent()) > 0): ?>
            <div class="col-12">
                <form action="<?php echo e(route('update_cart')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="table-content table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th class="kenne-product-remove">Xoá</th>
                                    <th class="kenne-product-thumbnail">hình ảnh</th>
                                    <th class="cart-product-name">Tên sản phẩm</th>
                                    <th class="kenne-product-price">Giá tiền</th>
                                    <th class="kenne-product-quantity">Số lượng</th>
                                    <th class="kenne-product-subtotal">Tổng tiền</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = Cart::getContent( ); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="kenne-product-remove"><a href="<?php echo e(route('delete_item_cart', $item->id)); ?>"><i class="fa fa-trash"
                                        title="Remove"></i></a></td>
                                    <td class="kenne-product-thumbnail"><a href="javascript:void(0)"><img src="/assets/images/product/small-size/1.jpg" alt="Uren's Cart Thumbnail"></a></td>
                                    <td class="kenne-product-name" ><a href="javascript:void(0)"><?php echo e($item->name); ?></a></td>
                                    <td class="kenne-product-price"><span class="amount"><?php echo e(number_format($item->price)); ?>₫</span></td>
                                    <td class="quantity">
                                        <label>số lượng</label>
                                        <div class="row">
                                            <p class="col-4">
                                            <span type="button" class="cart-plus-item btn text-dark border" data-id="<?php echo e($item->id); ?>" style="width: 30px; height: 30px;">+</span>
                                            </p>
                                            <input class="col-4" type="number" value="<?php echo e($item->quantity); ?>">
                                            <p class="col-4">
                                            <span type="button" class="cart-mines-item btn text-dark border" data-id="<?php echo e($item->id); ?>" style="width: 30px; height: 30px;"> - </span>
                                            </p>
                                        </div>
                                    </td>
                                    <td class="product-subtotal"><span class="amount"><?php echo e(number_format($item->price * $item->quantity)); ?>₫</span></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="coupon-all">
                                <div class="coupon">
                                    <input id="coupon_code" class="input-text" name="coupon_code" value="" placeholder="Coupon code" type="text">
                                    <input class="button" name="apply_coupon" value="Apply coupon" type="submit">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-5 ml-auto">
                            <div class="cart-page-total">
                                <h2>Tổng tiền</h2>
                                <ul>
                                    <li>Total <span><?php echo e(number_format(Cart::getTotal())); ?>₫</span></li>
                                </ul>
                                <a href="javascript:void(0)">Proceed to checkout</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <?php else: ?> 
            <h1>Chưa có sản phẩm nào trong giỏ hàng!</h1>
           <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DoAnChuyenNganh\project\storeapp\resources\views/frontend/cart/detail.blade.php ENDPATH**/ ?>