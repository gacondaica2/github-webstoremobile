
<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="page-header">
        <h2 class="header-title">Option</h2>
        <div class="header-sub-title">
            <nav class="breadcrumb breadcrumb-dash">
                <a href="<?php echo e(route('home')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>
            </nav>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <h4>Option</h4>
            <div class="m-t-25">
                <div class="card-body">
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label class="font-weight-semibold" for="dob">Manufacturer:</label>
                            <select name="status" id="status" class="form-control">
                                <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($manufacturer->id); ?>"><?php echo e($manufacturer->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="font-weight-semibold" for="dob">Hãng sản xuất:</label>
                            <select name="status" id="status" class="form-control">
                                <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($size->id); ?>"><?php echo e($size->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="font-weight-semibold" for="dob">rams:</label>
                            <select name="ram" id="status" class="form-control">
                                <?php $__currentLoopData = $rams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ram): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ram->id); ?>"><?php echo e($ram->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="font-weight-semibold" for="dob">Bộ nhớ trong:</label>
                            <select name="internalmemory" id="status" class="form-control">
                                <?php $__currentLoopData = $internalmemorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $internalmemory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($internalmemory->id); ?>"><?php echo e($internalmemory->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="font-weight-semibold" for="dob">Trọng lượng:</label>
                            <select name="weight" id="status" class="form-control">
                                <?php $__currentLoopData = $weights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($weight->id); ?>"><?php echo e($weight->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="font-weight-semibold" for="dob">Loại SIM:</label>
                            <select name="status" id="status" class="form-control">
                                <?php $__currentLoopData = $sims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sim->id); ?>"><?php echo e($sim->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="font-weight-semibold" for="dob">Kích thước màn hình:</label>
                            <select name="screensize" id="status" class="form-control">
                                <?php $__currentLoopData = $screensizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screensize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($screensize->id); ?>"><?php echo e($screensize->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="font-weight-semibold" for="dob">Độ phân giải màn hình:</label>
                            <select name="screenresolution" id="status" class="form-control">
                                <?php $__currentLoopData = $screenresolutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screenresolution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($screenresolution->id); ?>"><?php echo e($screenresolution->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="font-weight-semibold" for="dob">Loại màn hình:</label>
                            <select name="screen" id="status" class="form-control">
                                <?php $__currentLoopData = $screens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($screen->id); ?>"><?php echo e($screen->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="font-weight-semibold" for="dob">Hệ điều hành:</label>
                            <select name="operatingsystem" id="status" class="form-control">
                                <?php $__currentLoopData = $operatingsystems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operatingsystem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($operatingsystem->id); ?>"><?php echo e($operatingsystem->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-md-3">
                            <label class="font-weight-semibold" for="dob">pin:</label>
                            <select name="pin" id="status" class="form-control">
                                <?php $__currentLoopData = $pins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($pin->id); ?>"><?php echo e($pin->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div> 
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DoAnChuyenNganh\project\storeapp\resources\views/backend/option/index.blade.php ENDPATH**/ ?>