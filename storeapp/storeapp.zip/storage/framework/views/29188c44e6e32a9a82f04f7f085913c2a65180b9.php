
<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="page-header no-gutters has-tab">
        <h2 class="font-weight-normal"><?php echo e($item->title); ?></h2>
    </div>
    <?php echo $__env->make('backend.messages.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="tab-content m-t-15">
            <div class="tab-pane fade show active" id="tab-account" >
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo e($item->title); ?></h4>
                    </div>
                    <div class="card-body">
                        <hr class="m-v-25">
                        <form  action="<?php echo e(route('edit_post_product', $item->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label class="font-weight-semibold">Tiêu đề:</label>
                                    <input type="text" name="title" value="<?php echo e($item->title); ?>" class="form-control" id="title" placeholder="Tiêu đề">
                                </div>
                                <div class="form-group col-md-4">
                                    <label class="font-weight-semibold">Mã sản phẩm:</label>
                                    <input type="text" name="sku" value="<?php echo e($item->sku); ?>" class="form-control" id="sku" placeholder="Mã sản phẩm">
                                </div>
                                <div class="form-group col-md-4">
                                    <label class="font-weight-semibold">Giá:</label>
                                    <input type="number" name="price" value="<?php echo e($item->price); ?>" class="form-control" id="title" placeholder="Giá sản phẩm">
                                </div>
                                <div class="form-group col-md-4">
                                    <label class="font-weight-semibold">Giá khuyến mãi(nếu có):</label>
                                    <input type="number" name="price_sale" value="<?php echo e($item->price_sale); ?>" class="form-control" id="title" placeholder="Giá khuyễn mãi">
                                </div>
                                <div class="form-group col-md-4">
                                    <label class="font-weight-semibold" for="">Danh mục</label>
                                    <?php if( isset($parent) ): ?>
                                    <select name="category" id="childrent" class="form-control">
                                        <?php $__currentLoopData = $parent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chidlrent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($chidlrent->id); ?>" <?php echo e(($chidlrent->id == $item->category_id) ? 'selected': ""); ?>><?php echo e($chidlrent->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-2">
                                    <label class="font-weight-semibold" for="dob">Trạng thái(bật/tắt):</label>
                                    <select name="status" id="status" class="form-control">
                                        <option value="1">Bật</option>
                                        <option value="0">Tắt</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-2">
                                    <label class="font-weight-semibold">Số lượng sản phẩm:</label>
                                    <input type="text" name="qty" value="<?php echo e($item->qty); ?>" class="form-control" id="qty" placeholder="Số lượng">
                                </div>
                                <div class="col-md-12">
                                    <textarea name="editor"id="editor"><?php echo $item->content; ?></textarea>
                                </div>
                                <div class="col-md-12 mb-3"></div>
                                <div class="form-group col-md-3">
                                    <label class="font-weight-semibold">Khối lượng(gram):</label>
                                    <input type="number" name="weight" value="<?php echo e($item->weight); ?>" class="form-control" id="weight" placeholder="Khối lượng sản phẩm">
                                </div>
                                <div class="form-group col-md-3">
                                    <label class="font-weight-semibold">Chiều cao(cm):</label>
                                    <input type="number" name="height" class="form-control" value="<?php echo e($item->height); ?>" id="weight" placeholder="chiều cao sản phẩm">
                                </div>
                                <div class="form-group col-md-3">
                                    <label class="font-weight-semibold">Chiều rộng(cm):</label>
                                    <input type="number" name="width" class="form-control" id="weight" value="<?php echo e($item->width); ?>" placeholder="chiều rộng sản phẩm">
                                </div>
                                <div class="form-group col-md-12"><h2>Thông số cấu hình</h2> </div>
                                <div class="form-group col-md-3">
                                    <label class="font-weight-semibold">Hãng sản xuất(*):</label>
                                    <?php if( isset($manufacturers) ): ?>
                                    <select name="manufacturers" id="childrent" class="form-control">
                                        <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($manufacturer->id); ?>"><?php echo e($manufacturer->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <label class="font-weight-semibold">Kích thước(*):</label>
                                    <?php if( isset($sizes) ): ?>
                                    <select name="size" id="childrent" class="form-control">
                                        <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($size->id); ?>"><?php echo e($size->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <label class="font-weight-semibold">Trọng lượng(*):</label>
                                    <?php if( isset($weights) ): ?>
                                    <select name="weight_option" id="childrent" class="form-control">
                                        <?php $__currentLoopData = $weights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($weight->id); ?>"><?php echo e($weight->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <label class="font-weight-semibold">Bộ nhớ đệm / Ram(*):</label>
                                    <?php if( isset($internalmemorys) ): ?>
                                    <select name="internalmemory" id="childrent" class="form-control">
                                        <?php $__currentLoopData = $internalmemorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $internalmemory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($internalmemory->id); ?>"><?php echo e($internalmemory->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <label class="font-weight-semibold">Bộ nhớ trong(*):</label>
                                    <?php if( isset($rams) ): ?>
                                    <select name="ram" id="childrent" class="form-control">
                                        <?php $__currentLoopData = $rams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ram): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ram->id); ?>"><?php echo e($ram->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <label class="font-weight-semibold">Loại SIM(*):</label>
                                    <?php if( isset($sims) ): ?>
                                    <select name="sim" id="childrent" class="form-control">
                                        <?php $__currentLoopData = $sims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($sim->id); ?>"><?php echo e($sim->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <label class="font-weight-semibold">Loại màn hình(*):</label>
                                    <?php if( isset($screens) ): ?>
                                    <select name="screen" id="childrent" class="form-control">
                                        <?php $__currentLoopData = $screens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($screen->id); ?>"><?php echo e($screen->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <label class="font-weight-semibold">Kích thước màn hình(*):</label>
                                    <?php if( isset($screensizes) ): ?>
                                    <select name="screensize" id="childrent" class="form-control">
                                        <?php $__currentLoopData = $screensizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screensize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($screensize->id); ?>"><?php echo e($screensize->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <label class="font-weight-semibold">Độ phân giải màn hình(*):</label>
                                    <?php if( isset($screenresolutions) ): ?>
                                    <select name="screenresolution" id="childrent" class="form-control">
                                        <?php $__currentLoopData = $screenresolutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screenresolution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($screenresolution->id); ?>"><?php echo e($screenresolution->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <label class="font-weight-semibold">Hệ điều hành(*):</label>
                                    <?php if( isset($operatingsystems) ): ?>
                                    <select name="operatingsystem" id="childrent" class="form-control">
                                        <?php $__currentLoopData = $operatingsystems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operatingsystem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($operatingsystem->id); ?>"><?php echo e($operatingsystem->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-3">
                                    <label class="font-weight-semibold">Pin(*):</label>
                                    <?php if( isset($pins) ): ?>
                                    <select name="pin" id="childrent" class="form-control">
                                        <?php $__currentLoopData = $pins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($pin->id); ?>"><?php echo e($pin->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-3">
                                </div>
                                <div class="form-group col-md-3">
                                    <label class="font-weight-semibold">Ảnh đại diện:</label>
                                    <input type="file" name="avatar">
                                </div>
                                <div class="form-group col-md-3">
                                    <label class="font-weight-semibold">Ảnh mô tả:</label>
                                    <input class="media" type="file" name="media[]" multiple="multiple">
                                </div>
                                <div class="form-group col-md-3" style="width: 300px; height:300px;">
                                    <img src="/storage/images/<?php echo e($item->media->title); ?>" alt="image">
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">Chỉnh sửa</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DoAnChuyenNganh\project\storeapp\resources\views/backend/product/detail.blade.php ENDPATH**/ ?>