<?php if( Session::has('messages')): ?>
<div class="alert <?php echo e(Session::get('color')); ?>" >
    <strong> <?php echo e(Session::get('messages')); ?></strong>
</div>
<?php endif; ?><?php /**PATH D:\DoAnChuyenNganh\project\storeapp\resources\views/frontend/messages/messages.blade.php ENDPATH**/ ?>