
<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="page-header">
        <h2 class="header-title">Đơn hàng</h2>
        <div class="header-sub-title">
            <nav class="breadcrumb breadcrumb-dash">
                <a href="#" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>
            </nav>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <h4>Đơn hàng</h4>
            <div class="m-t-25">
                <p>ID: <?php echo e($record->id); ?></p>
                <p>Tên khách hàng: <?php echo e($record->Order_delivery->name); ?></p>
                <p>Địa chỉ: <?php echo e($record->Order_delivery->address); ?></p>
                <p>Số điện thoại: <?php echo e($record->Order_delivery->phone); ?></p>
                <p>Tình trạng đơn hàng: <?php echo e(($record->status == 0 )?"Chưa xác nhận" : "Đã xác nhận"); ?></p>
                <p>Tổng tiền: <?php echo e(number_format($record->total)); ?></p>
            </div>
            <div class="m-t-25">
                <table id="data-table" class="table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tên sản phẩm</th>
                            <th>Giá</th>
                            <th>Số lượng </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $record->order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e(number_format($item->price )); ?></td>
                                <td><?php echo e($item->qty); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php if( $record->status == 0): ?>
            <a href="<?php echo e(route('accept_order', $record->id)); ?>" class="btn btn-primary">xác nhận đơn hàng</a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DoAnChuyenNganh\project\storeapp\resources\views/backend/order/detail.blade.php ENDPATH**/ ?>