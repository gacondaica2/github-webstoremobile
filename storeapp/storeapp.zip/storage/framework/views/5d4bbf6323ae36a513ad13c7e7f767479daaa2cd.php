
<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="page-header">
        <h2 class="header-title">Option</h2>
        <div class="header-sub-title">
            <nav class="breadcrumb breadcrumb-dash">
                <a href="<?php echo e(route('home')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>
            </nav>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <h4>Option</h4>
            <div class="m-t-25">
                <div class="card-body">
                    <form action="<?php echo e(route('create_option')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-md-2">
                                <label class="font-weight-semibold" for="dob">Chọn Option:</label>
                                <select name="option" id="status" class="form-control option-click">
                                    <?php $__currentLoopData = \Helper::Option(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="form-row">
                                    <div class="form-group col-md-8">
                                        Tên
                                    </div>
                                    <div class="form-group col-md-2">
                                        Xoá
                                    </div>
                                    <div class="form-group col-md-2">
                                        Sửa
                                    </div>
                                </div>
                                <div class="form-row list-option">
                                    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-group col-md-8">
                                            <?php echo e($option->title); ?>

                                        </div>
                                        <div class="form-group col-md-2">
                                            <a href="<?php echo e(route('delete_option', ['id' => $option->id, 'option' => $position ])); ?>">Xoá</a>
                                        </div>
                                        <div class="form-group col-md-2">
                                            <a href="<?php echo e(route('edit_option_view', ['id' => $option->id, 'option' => $position ])); ?>">Sửa</a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="font-weight-semibold" for="dob">Tên Option mới :</label>
                                <input type="text" name="title" class="form-control" id="title" placeholder="Option mới">
                                <button class="btn" type="submit">Thêm</button>
                            </div>
                        </div> 
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DoAnChuyenNganh\project\storeapp\resources\views/backend/option/create.blade.php ENDPATH**/ ?>