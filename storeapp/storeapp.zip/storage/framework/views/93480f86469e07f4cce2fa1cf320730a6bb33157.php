<?php if(count( \Helper::BestSale())): ?>
<div class="list-product_area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title">
                    <h3>Sản phẩm bán chạy</span></h3>
                    <div class="list-product_arrow"></div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="kenne-element-carousel list-product_slider slider-nav" data-slick-options='{
                "slidesToShow": 3,
                "slidesToScroll": 1,
                "infinite": false,
                "arrows": true,
                "dots": false,
                "spaceBetween": 30,
                "appendArrows": ".list-product_arrow"
                }' data-slick-responsive='[
                {"breakpoint":1200, "settings": {
                "slidesToShow": 2
                }},
                {"breakpoint":768, "settings": {
                "slidesToShow": 1
                }},
                {"breakpoint":575, "settings": {
                "slidesToShow": 1
                }}
            ]'>
            <?php $__currentLoopData = \Helper::BestSale(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="product-item">
                        <div class="single-product">
                            <div class="product-img">
                                <a href="<?php echo e(route('detailItem',$item->slug)); ?>">
                                    <img width="150px" height="150px" class="primary-img" src="<?php echo e($item->img); ?>" alt="<?php echo e($item->title); ?>">
                                </a>
                                <?php if( $item->price_sale > 0 && $item->price_sale < $item->price): ?>
                                <span class="sticker-2">- <?php echo e(round( ($item->price - $item->price_sale) / $item->price * 100 )); ?>%</span>
                                <?php endif; ?>
                            </div>
                            <div class="product-content">
                                <div class="product-desc_info">
                                    <h3 class="product-name"><a href="<?php echo e(route('detailItem',$item->slug)); ?>"><?php echo e($item->title); ?></a>
                                    </h3>
                                    <div class="price-box">
                                    <?php if( $item->price_sale > 0 && $item->price_sale < $item->price ): ?>
                                        <span class="new-price"><?php echo e(number_format($item->price_sale)); ?>₫</span>
                                    <?php endif; ?>
                                        <span class="old-price"><?php echo e(number_format($item->price)); ?>₫</span>
                                    </div>
                                </div>
                                <div class="add-actions">
                                    <ul>
                                        <li><a href="<?php echo e(route('addTocart',$item->slug)); ?>" data-toggle="tooltip" data-placement="top" title="Add To Wishlist"><i class="ion-ios-heart-outline"></i></a>
                                        </li>
                                        <li class="btn add-to-cart" data-id="<?php echo e($item->id); ?>">Thêm giỏ hàng</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?><?php /**PATH D:\DoAnChuyenNganh\project\storeapp\resources\views/frontend/sale/bestsale.blade.php ENDPATH**/ ?>