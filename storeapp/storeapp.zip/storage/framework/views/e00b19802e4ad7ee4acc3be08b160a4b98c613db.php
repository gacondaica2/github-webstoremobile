
<?php $__env->startSection('content'); ?>
<div class="main-content">
    <div class="page-header">
        <h2 class="header-title">Option</h2>
        <div class="header-sub-title">
            <nav class="breadcrumb breadcrumb-dash">
                <a href="<?php echo e(route('home')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Home</a>
            </nav>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <h4>Option</h4>
            <div class="m-t-25">
                <div class="card-body">
                    <form action="<?php echo e(route('edit_option',  $record->id )); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="title" value="<?php echo e($record->title); ?>" class="form-control" id="option" placeholder="option">   
                        <input type="hidden" name="position" value="<?php echo e($position); ?>">
                        <button type="submit" class="btn">Sửa</button>
                    </form>
                </div> 
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DoAnChuyenNganh\project\storeapp\resources\views/backend/option/edit.blade.php ENDPATH**/ ?>